# Colored Overlay in Display Path

This sample shows 
 - how to place an OverlayBitmap into display path and draw graphcis in it
 - how to force the OverlayBitmap to color if the camera's video format is grey scale
 
 
The sampled needs IC Imaging Control 3.4 installed and minimum Visual Studio 2010 C++
