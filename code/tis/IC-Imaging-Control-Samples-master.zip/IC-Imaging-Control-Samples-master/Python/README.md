# Python samples for Windows

## Open Camera, Grab Image to OpenCV
This sample shows simple camera handling and how to snap images and forward them to OpenCV
